# Dubai Colour King Result — GitHub Pages

## Publish for free
1. Sign in to https://github.com/ and create a new **public** repository, for example `dubai-colour-king`.
2. Upload `index.html` to the repository's root (top level) and commit the change.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch **main** and folder **/(root)**, then click **Save**.
6. Wait a few minutes. GitHub will show your public website URL in the Pages section.

WhatsApp button is configured for +91 9996979872.
This starter site is informational only; it does not include betting, wagering, paid predictions, or payment collection.
